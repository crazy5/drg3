"""HIS → DRG 同步脚本。

部署在 88.3 桥接机上，每天凌晨 02:00 由 Windows 任务计划程序触发。
工作流程：
  1. 读环境变量（连 HIS + DRG 接收地址）
  2. SQL 关键字黑名单审计（防御）
  3. pyodbc 连 HIS（read-only intent）
  4. 跑只读 SQL 拉 [昨天 00:00, 今天 00:00) 的病案
  5. 字段映射 + 转 JSON
  6. httpx POST 给 DRG /api/sync/from-his
  7. 写本地同步日志 + 失败时 exit 1（让任务计划告警）

用法：
  python sync.py                              # 默认：拉昨日
  python sync.py --date 2026-03-15            # 补跑指定日期
  python sync.py --date 2026-03-15 --dry-run  # 只打 SQL 结果不 POST
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import re
import socket
import sys
import time
from datetime import date, datetime, time as dt_time, timedelta
from pathlib import Path

# ────────── 日志 ──────────

LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            LOG_DIR / f"sync-{datetime.now():%Y%m%d}.log",
            encoding="utf-8",
        ),
    ],
)
log = logging.getLogger("his_sync")

# ────────── HIS SQL（同步脚本唯一接触的 SQL，必须只读） ──────────

HIS_QUERY = r"""
WITH visits AS (
    SELECT *
    FROM TPATIENTVISIT
    WHERE FWORKRQ >= ? AND FWORKRQ < ?
),
ops AS (
    SELECT
        a.FPRN, a.FTIMES,
        MAX(CASE WHEN b.FPX = '1' THEN b.FOPCODE END)                       AS main_op_code,
        STUFF((
            SELECT ',' + b2.FOPCODE
            FROM TOPERATION b2
            WHERE b2.FPRN = a.FPRN AND b2.FTIMES = a.FTIMES AND b2.FPX <> '1'
            ORDER BY CAST(b2.FPX AS INT)
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 1, '')                             AS other_op_codes
    FROM visits a
    INNER JOIN TOPERATION b
        ON a.FPRN = b.FPRN AND a.FTIMES = b.FTIMES
    GROUP BY a.FPRN, a.FTIMES
),
diags AS (
    SELECT
        a.FPRN, a.FTIMES,
        MAX(CASE WHEN b.FZDLX = '1' THEN b.FICDM END)                        AS main_diag_code,
        STUFF((
            SELECT ',' + b2.FICDM
            FROM TDIAGNOSE b2
            WHERE b2.FPRN = a.FPRN AND b2.FTIMES = a.FTIMES AND b2.FZDLX <> '1'
            ORDER BY b2.FZDLX
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 1, '')                             AS other_diag_codes
    FROM visits a
    INNER JOIN TDIAGNOSE b
        ON a.FPRN = b.FPRN AND a.FTIMES = b.FTIMES
    GROUP BY a.FPRN, a.FTIMES
)
SELECT
    CONCAT(a.FPRN, '-', CONVERT(VARCHAR(8), a.FCYDATE, 112))                 AS case_id,
    a.FAGE                                                                   AS nl,
    a.FSEX                                                                   AS xb,
    a.FRYDATE                                                                AS admission_date,
    a.FCYDATE                                                                AS discharge_date,
    a.FCYDEPT                                                                AS discharge_department,
    a.FWORKRQ                                                                AS update_time,
    d.main_diag_code                                                         AS zyzd,
    d.other_diag_codes                                                       AS qtzd_list,
    o.main_op_code                                                           AS zyss,
    o.other_op_codes                                                         AS qtss_list
FROM visits a
INNER JOIN diags d ON a.FPRN = d.FPRN AND a.FTIMES = d.FTIMES
LEFT  JOIN ops   o ON a.FPRN = o.FPRN AND a.FTIMES = o.FTIMES
""".strip()


# ────────── SQL 关键字审计（第二道防线） ──────────

# 第一层：账号 db_datareader（数据库端）
# 第二层：以下黑名单（脚本端，防止 SQL 字符串被改坏）
FORBIDDEN_KEYWORDS = (
    "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE",
    "CREATE", "EXEC", "EXECUTE", "GRANT", "REVOKE", "MERGE",
    "BULK INSERT", "OPENROWSET", "OPENDATASOURCE", "OPENQUERY",
    "XP_", "SP_", "RESTORE", "BACKUP", "DBCC", "SHUTDOWN",
    "KILL", "RECONFIGURE", "DENY",
)


def assert_sql_readonly(sql: str) -> None:
    """确保 SQL 是只读的。

    步骤：
    1. 去掉 -- 行注释
    2. 去掉 /* ... */ 块注释（嵌套不处理，SQL Server 不允许嵌套）
    3. 去掉字符串字面量 '...'（避免字符串里塞关键字绕过）
    4. 用词边界扫黑名单
    """
    stripped = re.sub(r"--[^\n]*", "", sql)
    stripped = re.sub(r"/\*.*?\*/", "", stripped, flags=re.DOTALL)
    stripped = re.sub(r"'(?:''|[^'])*'", "''", stripped)

    upper = stripped.upper()
    for kw in FORBIDDEN_KEYWORDS:
        # 词边界匹配，避免误杀（例如 INSERTED 是列名，但 UPDATE/DELETE 等不允许）
        pattern = r"\b" + re.escape(kw) + r"\b"
        if re.search(pattern, upper):
            raise RuntimeError(
                f"SQL 安全审计失败：发现禁止关键字 '{kw}'。"
                "此同步脚本禁止任何 DML/DDL/DCL 操作，只允许 SELECT。"
            )

    if not re.search(r"\bSELECT\b", upper):
        raise RuntimeError("SQL 必须以 SELECT 开头")


# ────────── HIS 行 → DRG payload ──────────


def normalize_date(v):
    """HIS 返回的 datetime/date → 'YYYY-MM-DD' 字符串；None 透传。"""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, date):
        return v.strftime("%Y-%m-%d")
    return str(v)


def normalize_dt(v):
    """HIS 返回的 datetime → 'YYYY-MM-DD HH:MM:SS' 字符串；None 透传。"""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    return str(v)


def split_codes(v):
    """'A01.001,B02.002,B99' → ['A01.001','B02.002','B99']，统一大写去末尾点。"""
    if not v:
        return []
    if isinstance(v, (bytes, bytearray)):
        v = v.decode("utf-8", errors="ignore")
    s = str(v).strip()
    if not s:
        return []
    out = []
    for x in s.replace(";", ",").split(","):
        x = x.strip().upper().rstrip(".")
        if x:
            out.append(x)
    return out


def his_row_to_case(row: dict) -> dict:
    """HIS 一行 → DRG /api/sync/from-his 期望的 JSON。"""
    return {
        "case_id": (row.get("case_id") or "").strip(),
        "zyzd": (row.get("zyzd") or "").strip().upper().rstrip("."),
        "zyss": ((row.get("zyss") or "") or "").strip().upper().rstrip(".") or None,
        "qtzd_list": split_codes(row.get("qtzd_list")),
        "qtss_list": split_codes(row.get("qtss_list")),
        "nl": row.get("nl"),
        "xb": row.get("xb"),
        "admission_date": normalize_date(row.get("admission_date")),
        "discharge_date": normalize_date(row.get("discharge_date")),
        "discharge_department": (str(row.get("discharge_department") or "")).strip() or None,
        "update_time": normalize_dt(row.get("update_time")),
    }


# ────────── 主流程 ──────────


def fetch_from_his(start_dt: datetime, end_dt: datetime):
    """连 HIS 跑查询，返回 list[dict]。"""
    import pyodbc

    host = os.environ.get("HIS_DB_HOST")
    user = os.environ.get("HIS_DB_USER")
    pwd = os.environ.get("HIS_DB_PASSWORD")
    db = os.environ.get("HIS_DB_NAME")
    if not all([host, user, pwd, db]):
        raise RuntimeError(
            "环境变量未配置完整：需要 HIS_DB_HOST / HIS_DB_USER / HIS_DB_PASSWORD / HIS_DB_NAME"
        )

    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={host};"
        f"DATABASE={db};"
        f"UID={user};"
        f"PWD={pwd};"
        f"ApplicationIntent=ReadOnly;"          # ★ 只读意图（连接级防护）
    )
    log.info("连接 HIS: %s/%s (ReadOnly)", host, db)
    conn = pyodbc.connect(conn_str, timeout=30, autocommit=True)
    try:
        with conn.cursor() as cur:
            # ★ 进一步防长锁
            cur.execute("SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED")
            log.info("执行 HIS 查询（窗口 [%s, %s)）", start_dt, end_dt)
            cur.execute(HIS_QUERY, start_dt, end_dt)
            cols = [c[0] for c in cur.description]
            rows = [dict(zip(cols, r)) for r in cur.fetchall()]
            log.info("HIS 返回 %d 条", len(rows))
            return rows
    finally:
        conn.close()


def post_to_drg(payload: dict, retries: int = 3) -> dict:
    """POST 给 DRG /api/sync/from-his，带重试。"""
    import httpx

    base = os.environ["DRG_API_URL"].rstrip("/")
    url = f"{base}/api/sync/from-his"
    timeout = httpx.Timeout(60.0, connect=10.0)

    last_exc = None
    for attempt in range(1, retries + 1):
        try:
            log.info("POST %s (attempt %d/%d, %d cases)",
                     url, attempt, retries, len(payload.get("cases", [])))
            r = httpx.post(url, json=payload, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:        # noqa: BLE001
            last_exc = e
            log.warning("POST 失败 (attempt %d): %s", attempt, e)
            time.sleep(2 ** attempt)
    raise RuntimeError(f"POST {url} 重试 {retries} 次仍失败: {last_exc}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", help="补跑指定日期（YYYY-MM-DD），默认昨天")
    parser.add_argument("--dry-run", action="store_true", help="只查不推")
    parser.add_argument("--batch-size", type=int, default=200,
                        help="每批推多少条病案给 DRG，默认 200")
    args = parser.parse_args()

    target_date = (
        datetime.strptime(args.date, "%Y-%m-%d").date()
        if args.date else date.today() - timedelta(days=1)
    )
    start_dt = datetime.combine(target_date, dt_time(0, 0, 0))
    end_dt = start_dt + timedelta(days=1)
    log.info("同步窗口：%s → %s", start_dt, end_dt)

    # 1. SQL 安全审计
    assert_sql_readonly(HIS_QUERY)
    log.info("SQL 安全审计通过（只读）")

    # 2. 拉 HIS
    rows = fetch_from_his(start_dt, end_dt)
    if not rows:
        log.info("HIS 无新增病案，退出")
        return 0

    # 3. 字段映射
    cases = []
    skipped = 0
    for r in rows:
        c = his_row_to_case(r)
        if not c["case_id"]:
            log.warning("跳过无 case_id 行: %r", r)
            skipped += 1
            continue
        cases.append(c)
    log.info("映射后 %d 条病案（跳过 %d 条无 case_id）", len(cases), skipped)

    if args.dry_run:
        log.info("[DRY-RUN] 不实际推送；首条样例：%s", json.dumps(cases[0], ensure_ascii=False, indent=2))
        return 0

    # 4. 分批 POST
    source = f"{socket.gethostname()}({os.environ.get('HIS_DB_HOST','')})"
    overall = {"received": 0, "inserted": 0, "updated": 0,
               "succeeded": 0, "fallback": 0, "failed": 0,
               "log_id": None, "batches": 0}

    for i in range(0, len(cases), args.batch_size):
        batch = cases[i:i + args.batch_size]
        payload = {
            "source": source,
            "start_date": target_date.isoformat(),
            "end_date": end_dt.date().isoformat(),
            "cases": batch,
        }
        resp = post_to_drg(payload)
        overall["received"] += resp.get("received", 0)
        overall["inserted"] += resp.get("inserted", 0)
        overall["updated"] += resp.get("updated", 0)
        overall["succeeded"] += resp.get("succeeded", 0)
        overall["fallback"] += resp.get("fallback", 0)
        overall["failed"] += resp.get("failed", 0)
        overall["log_id"] = resp.get("log_id")
        log.info(
            "批次 %d/%d 完成：log_id=%s 状态=%s 收=%d 插=%d 更=%d 成=%d 兜=%d 败=%d",
            (i // args.batch_size) + 1,
            (len(cases) + args.batch_size - 1) // args.batch_size,
            resp.get("log_id"), resp.get("status"),
            resp.get("received"), resp.get("inserted"),
            resp.get("updated"), resp.get("succeeded"),
            resp.get("fallback"), resp.get("failed"),
        )

    log.info(
        "本次同步完成：log_id=%s 收=%d 插=%d 更=%d 成功=%d 兜底=%d 失败=%d",
        overall["log_id"], overall["received"], overall["inserted"],
        overall["updated"], overall["succeeded"], overall["fallback"],
        overall["failed"],
    )

    # 5. 失败时 exit 1，让任务计划发邮件告警
    return 0 if overall["failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())